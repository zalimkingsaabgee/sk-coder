export type RuntimeDispatch = {
    runtime: string;
    filename: string;
    workspaceCommand: string;
    ephemeralCommand: string;
};

const dispatches: Record<string, RuntimeDispatch> = {
    python: { runtime: "python", filename: "main.py", workspaceCommand: "python3 main.py", ephemeralCommand: "python3 main.py" },
    python3: { runtime: "python", filename: "main.py", workspaceCommand: "python3 main.py", ephemeralCommand: "python3 main.py" },
    py: { runtime: "python", filename: "main.py", workspaceCommand: "python3 main.py", ephemeralCommand: "python3 main.py" },
    node: { runtime: "node", filename: "main.js", workspaceCommand: "node main.js", ephemeralCommand: "node main.js" },
    nodejs: { runtime: "node", filename: "main.js", workspaceCommand: "node main.js", ephemeralCommand: "node main.js" },
    javascript: { runtime: "node", filename: "main.js", workspaceCommand: "node main.js", ephemeralCommand: "node main.js" },
    js: { runtime: "node", filename: "main.js", workspaceCommand: "node main.js", ephemeralCommand: "node main.js" },
    mjs: { runtime: "node", filename: "main.mjs", workspaceCommand: "node main.mjs", ephemeralCommand: "node main.mjs" },
    cjs: { runtime: "node", filename: "main.cjs", workspaceCommand: "node main.cjs", ephemeralCommand: "node main.cjs" },
    typescript: { runtime: "typescript", filename: "main.ts", workspaceCommand: "tsx main.ts", ephemeralCommand: "tsx main.ts" },
    ts: { runtime: "typescript", filename: "main.ts", workspaceCommand: "tsx main.ts", ephemeralCommand: "tsx main.ts" },
    tsx: { runtime: "typescript", filename: "main.tsx", workspaceCommand: "tsx main.tsx", ephemeralCommand: "tsx main.tsx" },
    bash: { runtime: "bash", filename: "main.sh", workspaceCommand: "bash main.sh", ephemeralCommand: "bash main.sh" },
    shell: { runtime: "bash", filename: "main.sh", workspaceCommand: "bash main.sh", ephemeralCommand: "bash main.sh" },
    sh: { runtime: "bash", filename: "main.sh", workspaceCommand: "bash main.sh", ephemeralCommand: "bash main.sh" },
    java: { runtime: "java", filename: "Main.java", workspaceCommand: "javac Main.java && java Main", ephemeralCommand: "javac Main.java && java Main" },
    c: { runtime: "c", filename: "main.c", workspaceCommand: "gcc main.c -O2 -o main && ./main", ephemeralCommand: "gcc main.c -O2 -o main && ./main" },
    cpp: { runtime: "cpp", filename: "main.cpp", workspaceCommand: "g++ main.cpp -O2 -o main && ./main", ephemeralCommand: "g++ main.cpp -O2 -o main && ./main" },
    cc: { runtime: "cpp", filename: "main.cpp", workspaceCommand: "g++ main.cpp -O2 -o main && ./main", ephemeralCommand: "g++ main.cpp -O2 -o main && ./main" },
    cxx: { runtime: "cpp", filename: "main.cpp", workspaceCommand: "g++ main.cpp -O2 -o main && ./main", ephemeralCommand: "g++ main.cpp -O2 -o main && ./main" },
    csharp: { runtime: "csharp", filename: "Program.cs", workspaceCommand: "rm -rf .skcoder-dotnet && dotnet new console --force --output .skcoder-dotnet >/dev/null && cp Program.cs .skcoder-dotnet/Program.cs && dotnet run --project .skcoder-dotnet", ephemeralCommand: "dotnet new console --force --output app >/dev/null && cp Program.cs app/Program.cs && dotnet run --project app" },
    cs: { runtime: "csharp", filename: "Program.cs", workspaceCommand: "rm -rf .skcoder-dotnet && dotnet new console --force --output .skcoder-dotnet >/dev/null && cp Program.cs .skcoder-dotnet/Program.cs && dotnet run --project .skcoder-dotnet", ephemeralCommand: "dotnet new console --force --output app >/dev/null && cp Program.cs app/Program.cs && dotnet run --project app" },
    kotlin: { runtime: "kotlin", filename: "Main.kt", workspaceCommand: "kotlinc Main.kt -include-runtime -d main.jar && java -jar main.jar", ephemeralCommand: "kotlinc Main.kt -include-runtime -d main.jar && java -jar main.jar" },
    kt: { runtime: "kotlin", filename: "Main.kt", workspaceCommand: "kotlinc Main.kt -include-runtime -d main.jar && java -jar main.jar", ephemeralCommand: "kotlinc Main.kt -include-runtime -d main.jar && java -jar main.jar" },
    kts: { runtime: "kotlin", filename: "Main.kts", workspaceCommand: "kotlinc -script Main.kts", ephemeralCommand: "kotlinc -script Main.kts" },
    rust: { runtime: "rust", filename: "main.rs", workspaceCommand: "rustc main.rs -O -o main && ./main", ephemeralCommand: "rustc main.rs -O -o main && ./main" },
    rs: { runtime: "rust", filename: "main.rs", workspaceCommand: "rustc main.rs -O -o main && ./main", ephemeralCommand: "rustc main.rs -O -o main && ./main" },
    go: { runtime: "go", filename: "main.go", workspaceCommand: "mkdir -p .go-tmp && TMPDIR=$PWD/.go-tmp go run main.go", ephemeralCommand: "mkdir -p .go-tmp && TMPDIR=$PWD/.go-tmp go run main.go" },
    php: { runtime: "php", filename: "main.php", workspaceCommand: "php main.php", ephemeralCommand: "php main.php" },
    ruby: { runtime: "ruby", filename: "main.rb", workspaceCommand: "ruby main.rb", ephemeralCommand: "ruby main.rb" },
    rb: { runtime: "ruby", filename: "main.rb", workspaceCommand: "ruby main.rb", ephemeralCommand: "ruby main.rb" },
};

export function resolveRuntimeDispatch(language: string) {
    return dispatches[language.trim().toLowerCase()] ?? null;
}

export function runtimeDispatchCatalog() {
    return Object.entries(dispatches).map(([language, dispatch]) => ({ language, ...dispatch }));
}