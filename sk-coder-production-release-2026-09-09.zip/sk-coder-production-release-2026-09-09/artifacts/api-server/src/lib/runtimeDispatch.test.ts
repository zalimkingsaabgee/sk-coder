import { describe, expect, it } from "vitest";
import { resolveRuntimeDispatch, runtimeDispatchCatalog } from "./runtimeDispatch.js";

describe("runtime dispatch", () => {
    it("has a dispatch for every declared runtime", () => {
        const runtimes = new Set(["node", "typescript", "python", "java", "kotlin", "csharp", "c", "cpp", "rust", "go", "php", "ruby", "bash"]);
        expect(new Set(runtimeDispatchCatalog().map((entry) => entry.runtime))).toEqual(runtimes);
    });

    it.each(["python3", "mjs", "tsx", "cxx", "cs", "kts", "rs", "rb", "sh"])("normalizes %s to a runnable profile", (language) => {
        expect(resolveRuntimeDispatch(language)).toMatchObject({ filename: expect.any(String), workspaceCommand: expect.any(String), ephemeralCommand: expect.any(String) });
    });

    it("returns null for unknown languages", () => {
        expect(resolveRuntimeDispatch("ada")).toBeNull();
    });
});