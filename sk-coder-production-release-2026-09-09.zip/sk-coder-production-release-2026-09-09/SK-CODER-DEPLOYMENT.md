# SK Coder release package

This package contains the complete SK Coder source:

- `artifacts/sk-ide` — React/Vite frontend with Monaco, file explorer, terminal UI, previews, AI panel, GUI panel, and APK tools.
- `artifacts/api-server` — Express/WebSocket backend for workspaces, terminal sessions, staging, previews, GUI sessions, APK jobs, and isolated execution.
- `pnpm-lock.yaml`, `pnpm-workspace.yaml`, `tsconfig*`, `.replit` — workspace and deployment configuration.

## Verified release checks

The source was verified before packaging:

- Frontend TypeScript check: passed.
- Frontend production build: passed.
- Backend TypeScript check: passed.
- Backend test suite: 8 files and 46 tests passed.
- API health endpoint: `GET /api/healthz` returns `{"status":"ok"}`.
- Frontend preview: renders successfully without browser console errors.

## Important production prerequisite

SK Coder's heavy execution features intentionally use Docker containers. A production host must provide:

1. A running Docker Engine.
2. The backend's access to the Docker socket or an equivalent Docker API.
3. The configured runtime images:

   - `sk-coder-runtime:latest`
   - `sk-coder-gui:latest`
   - `sk-coder-apk:latest`

The frontend and API build without Docker. If the runtime images or Docker Engine are missing, the API remains available and reports runtime-unavailable states instead of silently pretending that execution succeeded, but server-side execution, GUI sessions, and APK jobs cannot run.

## Local or Oracle VM setup

Requirements:

- Node.js 22+
- pnpm
- Docker Engine
- A reverse proxy such as Nginx or Caddy for HTTPS and WebSocket forwarding

Install dependencies and verify the application:

```bash
corepack enable
pnpm install --frozen-lockfile
pnpm --filter @workspace/sk-ide run typecheck
pnpm --filter @workspace/sk-ide run build
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server exec vitest run
```

Start the API:

```bash
cd artifacts/api-server
PORT=3001 \
WORKSPACE_ROOT=/var/lib/sk-coder/workspaces \
node dist/index.js
```

Build and serve the frontend:

```bash
pnpm --filter @workspace/sk-ide run build
```

Serve `artifacts/sk-ide/dist/public` through Nginx. Proxy `/api` and `/ws` to the API service, preserve the `X-Device-Id` and `X-SK-Workspace-Access` headers, and enable WebSocket upgrades. Keep ports 3001 and the frontend development port private; expose only HTTPS.

Check the service:

```bash
curl -fsS https://YOUR_DOMAIN/api/healthz
```

Expected response:

```json
{"status":"ok"}
```

## Replit deployment

The checked-in `.replit` file starts the API workflow and exposes the configured web/API ports. The managed `artifacts/sk-ide/.replit-artifact/artifact.toml` contains the frontend production build definition.

Before publishing on any host, configure the runtime image names and persistent `WORKSPACE_ROOT` storage for that host. Do not place API keys, Docker credentials, or session secrets in this archive; configure them through the host's secret/environment-variable manager.

## Stability notes

- Workspace files are staged with manifest deltas, chunk uploads, revision checks, and retries.
- Terminal reconnects preserve the workspace lease and retry with backoff.
- Browser file changes remain available if the backend is temporarily offline.
- Runtime failures are surfaced explicitly instead of being reported as successful runs.
- Persistent workspace storage is required in production; do not use an ephemeral container filesystem for `WORKSPACE_ROOT`.

The archive is source-complete and publishable after the host-specific Docker runtime images, persistent storage, HTTPS, and environment configuration are supplied.