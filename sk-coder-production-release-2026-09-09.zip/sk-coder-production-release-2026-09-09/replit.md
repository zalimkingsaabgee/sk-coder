# Workspace

## Overview

SK Studio — a professional-grade mobile-first IDE built with React + Vite and a Node/Express backend.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + Tailwind CSS + Monaco Editor
- **AI**: OpenAI via Replit AI Integrations (gpt-5-mini)

## Artifacts

### SK Studio IDE (`artifacts/sk-ide`)
- Main IDE with Monaco Editor, file explorer, AI chat assistant
- Routes: `/` (IDE), `/projects`, `/ai`, `/settings`
- Dark VS Code-inspired theme
- Mobile-optimized with bottom nav bar

### API Server (`artifacts/api-server`)
- Express 5 backend
- Routes: `/api/projects`, `/api/ai/chat`, `/api/healthz`
- Integrated with OpenAI via Replit AI Integrations

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/sk-ide run dev` — run frontend locally

## Database Schema

- `projects` — stores saved projects with name, language, files (JSON), description

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
